#ifndef INSTRUCTION_H
#define INSTRUCTION_H

#include <stdio.h>
#include <stdlib.h>

// 全局变量声明
extern long pc;
extern int OPCODE;
extern int RS1;
extern int RS2;
extern int RD;
extern int IMM;
extern unsigned int UIMM;
extern int FUNC;
extern int OFFSET;
extern int FMT;
extern int FRS1;
extern int FRS2;
extern int FRD;
extern int FUNCT;

// MIPS指令解码函数声明
void MIPS_decoder(long pc);
//执行函数声明
void Execution(void) ;
// 指令执行函数声明
long INSN_ADD(long pc);
long INSN_ADDU(long pc);
long INSN_SUB(long pc);
long INSN_SUBU(long pc);
long INSN_AND(long pc);
long INSN_OR(long pc);
long INSN_XOR(long pc);
long INSN_NOR(long pc);
long INSN_SLT(long pc);
long INSN_SLTU(long pc);
long INSN_SLL(long pc);
long INSN_SRL(long pc);
long INSN_SRA(long pc);
long INSN_SLLV(long pc);
long INSN_SRLV(long pc);
long INSN_SRAV(long pc);
long INSN_JR(long pc);
long INSN_ADDI(long pc);
long INSN_ADDUI(long pc);
long INSN_NOP(long pc);
long INSN_J(long pc);
long INSN_JAL(long pc);
long INSN_ANDI(long pc);
long INSN_ORI(long pc);
long INSN_XORI(long pc);
long INSN_LUI(long pc);
long INSN_LW(long pc);
long INSN_SW(long pc);
long INSN_BEQ(long pc);
long INSN_BNE(long pc);
long INSN_SLTI(long pc);
long INSN_SLTIU(long pc);
long INSN_LWC1(long pc); // 新增浮点指令 LWC1 声明
long INS_SWC1(long pc); // 新增浮点指令 SWC1 声明
long INSN_ADD_S(long pc); // 新增浮点指令 ADD_S 声明
long INSN_MUL_S(long pc); // 新增浮点指令 MUL_S 声明
long INSN_OR(long pc);
long INSN_XOR(long pc);
long INSN_NOR(long pc);
long INSN_SLT(long pc);
long INSN_SLTU(long pc);
#endif // INSTRUCTION_H
