#include <stdio.h>
#include "Registers.h"

int main() {
    // 初始化寄存器文件
    init_registers();

    // 测试写入和读取有符号整数
    put_int(0, 0);
    put_int(1, -100);
    printf("get_int(0) = %d\n", get_int(0));
    printf("get_int(1) = %d\n", get_int(1));

    // 测试写入和读取无符号整数
    put_uint(2, 4294967295U); // 无符号最大值
    printf("get_unit(2) = %u\n", get_uint(2));

    // 释放寄存器文件
    free_registers();

    return 0;
}
