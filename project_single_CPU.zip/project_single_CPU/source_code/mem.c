#include <stdio.h>
#include <stdlib.h>
#include <mem.h>

char *mem;                      //  主存起始地址指针 
int mem_size=0x080000;   //  主存的大小 （int）524288

// 从指定的内存地址读取一个无符号字节（unsigned char）
unsigned char read_mem_ubyte(long addr)
{
    // 将内存地址 mem + addr 转换为 unsigned char 类型的指针，并返回指向该地址的值
    return *((unsigned char *) (mem+addr)); 
}

// 向指定的内存地址写入一个无符号字节（unsigned char）
void write_mem_ubyte(long addr , unsigned char val)
{
    // 将内存地址 mem + addr 转换为 unsigned char 类型的指针，并将 val 写入该地址
    *(unsigned char *) (mem+addr) = val; 
}

// 从指定地址读取一个有符号字节的内存
char read_mem_byte (long addr)
{
    // 将地址转换为 char 指针，然后解引用取得该地址的字节
    return *((char *) (mem+addr)) ;
}

// 向指定地址写入一个有符号字节
void write_mem_byte (long addr , char val)
{
    // 将地址转换为 char 指针，并将 val 写入该地址
    *(char *) (mem + addr) = val;
}

// 从指定地址读取一个无符号半字（unsigned short）
unsigned short read_mem_uhalf_word (long addr)
{
    // 将地址转换为 unsigned short 指针，然后解引用取得该地址的半字
    return *((unsigned short *) (mem+addr)); 
}

// 向指定地址写入一个无符号半字（unsigned short）
void write_mem_uhalf_word (long addr , unsigned short val)
{
    // 将地址转换为 unsigned short 指针，并将 val 写入该地址
    *(unsigned short *) (mem + addr) = val ;
}

// 从指定地址读取一个有符号半字（short）
short read_mem_half_word (long addr)
{
    // 将地址转换为 short 指针，然后解引用取得该地址的半字
    return  *((short *)(mem + addr));
}

// 向指定地址写入一个有符号半字（short）
void write_mem_half_word (long addr , short val)
{
    // 将地址转换为 short 指针，并将 val 写入该地址
    *((short *)(mem + addr)) = val ;
}

// 从指定地址读取一个无符号整数（unsigned int）
unsigned int read_mem_uword (long addr)
{
    // 将地址转换为 unsigned int 指针，然后解引用取得该地址的整数
    return *((unsigned int *) (mem + addr));
}

// 向指定地址写入一个无符号整数（unsigned int）
void write_mem_uword (long addr , unsigned int val)
{
    // 将地址转换为 unsigned int 指针，并将 val 写入该地址
    *((unsigned int *) (mem + addr)) = val ;
}

// 从指定地址读取一个有符号整数（int）
int read_mem_word (long addr)
{
    // 将地址转换为 int 指针，然后解引用取得该地址的整数
    return *((int *) (mem+ addr)) ;
}

// 向指定地址写入一个有符号整数（int）
void write_mem_word (long addr , int val)
{
    // 将地址转换为 int 指针，并将 val 写入该地址
    *((int *) (mem + addr)) = val;
}

// 从指定地址读取一个浮点数（float）
float read_mem_float (long addr)
{
    return *((float *) (mem + addr)); // 将地址转换为 float 指针，然后解引用取得该地址的 float 值
}

// 向指定地址写入一个浮点数（float）
void write_mem_float (long addr , float val)
{
    *(float *) (mem + addr) = val; // 将地址转换为 float 指针，并将 val 写入该地址
}

// 从指定地址读取一个双精度浮点数（double）
double read_mem_double (long addr)
{
    return *((double *) (mem + addr)); // 将地址转换为 double 指针，然后解引用取得该地址的 double 值
}

// 向指定地址写入一个双精度浮点数（double）
void write_mem_double (long addr , double val)
{
    *(double *) (mem + addr) = val; // 将地址转换为 double 指针，并将 val 写入该地址
}

void init_mem() {
    mem = (char *)malloc(sizeof(char) * mem_size); // 创建内存
    if (mem == NULL)
    {
        printf("error: main memory allocation\n");
        exit(-1);
    }
}

// 释放寄存器文件
void free_mem() {
    free(mem);
}
