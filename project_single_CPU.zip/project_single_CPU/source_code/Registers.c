//Registers.c
#include <stdio.h>
#include <stdlib.h>

int   ireg_size = 32;       // 通用寄存器文件的大小 
int  *r;                    // 通用寄存器文件起始地址指针 

int get_int(long addr) 
{ 
    return *((int *)(r+addr)); 
} 
 
void put_int(long addr, int val) 
{ 
*((int *)(r+addr)) = val; 
} 

int get_uint(long addr) 
{ 
return *((unsigned int*)(r+addr)); 
} 
 
void put_uint(long addr, unsigned int val) 
{ 
    *((unsigned int *)(r+addr)) = val; 
}

// 初始化寄存器文件
void init_registers() {
    // 分配32个int大小的内存空间给寄存器文件
    r = (int *)malloc(sizeof(int) * ireg_size);
    if (r == NULL) {
        printf("error: int. Register file allocation\n");
        exit(-1);
    }
    // 初始化寄存器为0
    for (int i = 0; i < ireg_size; i++) {
        put_int(i, 0);
    }
}

// 释放寄存器文件
void free_registers() {
    free(r);
}
