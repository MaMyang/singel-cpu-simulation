//test_0.c
#include <stdio.h>
#include <stdlib.h>
#include "mem.h" // 包含内存模拟的头文件
#include "opcode_and_function.h"
#include "Registers.h"
#include "Instruction.h"
#define R0 0 

int main(void)
{
    init_mem();
    init_registers();
    int i1 = 16, i2 = -35, i3; 
    put_int( 2, i1 );  // R2 = 16 
    put_int( 3, i2 );   // R3 = -35
    write_mem_uword( 0x1000,  0x00430820);  // mem[0x1000] = ADD R1, R2, R3 
    write_mem_uword( 0x1004, 0x00000008 );  // mem[0x1004] = JR R0
    Execution();       // execution above two MIPS instructions
    i3 = get_int( 1 );
    printf( "r1 = %d\n", i3 );  
    free_mem();
    free_registers();

    return 0;
}
