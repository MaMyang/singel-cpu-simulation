//test_1.c
//测试浮点数的读取
#include <stdio.h>
#include <stdlib.h>
#include "mem.h" // 包含内存模拟的头文件
#include "opcode_and_function.h"
#include "Registers.h"
#include "Instruction.h"
#include "f_register.h"
#define R0 0 

int main(void)
{
    init_mem();
    init_registers();
    init_f_registers(); // 初始化浮点寄存器

    float float_data = 3.1415926; // 定义单精度浮点数
    float result; // 存储结果的变量
    float f0 = get_float(0) ;
    printf("f0: %f\n", result); // 打印结果

    // 将浮点数写入内存
    write_mem_float(0x2000, float_data); // mem[0x2000] = 3.1415926
    result = read_mem_float(0x2000); // result = mem[0x2004]
    printf("Result: %f\n", result); // 打印结果


    // 加载数据到浮点寄存器
    write_mem_uword(0x1000, 0xC4002000); // mem[0x1000] = LWC1 $f0, 0x2000($zero)
    // 存储数据到内存
    write_mem_uword(0x1004, 0xE4002004); // mem[0x1004] = SWC1 $f0, 0x2004($zero)
    // 返回指令
    write_mem_uword(0x1008, 0x00000008); // mem[0x1008] = JR $ra

    Execution(); 
    f0 = get_float(0) ;
    printf("f0: %f\n", result); // 打印结果
    result = read_mem_float(0x2004); // result = mem[0x2004]
    printf("Result: %f\n", result); // 打印结果

    free_mem();
    free_registers();
    free_f_registers(); // 释放浮点寄存器

    return 0;
}
