// test_mem.c
#include <stdio.h>
#include <stdlib.h>
#include "mem.h" // 包含内存模拟的头文件

int main(void)
{
    unsigned char uh1, uh2;
    char h1, h2;
    unsigned short ush1, ush2;
    short sh1, sh2;
    unsigned int uw1, uw2;
    int w1, w2;
    float f1, f2;
    double d1, d2;
    unsigned long addr = 256;

    mem = (char *)malloc(sizeof(char) * mem_size); // 创建内存
    if (mem == NULL)
    {
        printf("error: main memory allocation\n");
        exit(-1);
    }

    // 测试 unsigned char
    uh1 = 0x0f5; // 实际值为 245，0x0f5 在 unsigned char 中只取低8位
    write_mem_ubyte(addr, uh1);
    uh2 = read_mem_ubyte(addr);
    printf("uh1=%u, uh2=%u\n", uh1, uh2);

    // 测试 char
    h1 = -10; // 实际值为 -10
    write_mem_byte(addr + 1, h1);
    h2 = read_mem_byte(addr + 1);
    printf("h1=%d, h2=%d\n", h1, h2);

    // 测试 unsigned short
    ush1 = 0x0f5a; // 实际值为 3962
    write_mem_uhalf_word(addr + 2, ush1);
    ush2 = read_mem_uhalf_word(addr + 2);
    printf("ush1=%u, ush2=%u\n", ush1, ush2);

    // 测试 short
    sh1 = -100; // 实际值为 -100
    write_mem_half_word(addr + 4, sh1);
    sh2 = read_mem_half_word(addr + 4);
    printf("sh1=%d, sh2=%d\n", sh1, sh2);

    // 测试 unsigned int
    uw1 = 0x0f5a3c23; // 实际值为 257160547
    write_mem_uword(addr + 6, uw1);
    uw2 = read_mem_uword(addr + 6);
    printf("uw1=%u, uw2=%u\n", uw1, uw2);

    // 测试 int
    w1 = -257160547; // 实际值为 -257160547
    write_mem_word(addr + 10, w1);
    w2 = read_mem_word(addr + 10);
    printf("w1=%d, w2=%d\n", w1, w2);

    // 测试 float
    f1 = 3.14159f; // 实际值为 3.14159
    write_mem_float(addr + 14, f1);
    f2 = read_mem_float(addr + 14);
    printf("f1=%f, f2=%f\n", f1, f2);

    // 测试 double
    d1 = 2.71828; // 实际值为 2.71828
    write_mem_double(addr + 18, d1);
    d2 = read_mem_double(addr + 18);
    printf("d1=%f, d2=%f\n", d1, d2);

    free(mem);

    return 0;
}
