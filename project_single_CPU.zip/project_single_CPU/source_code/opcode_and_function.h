enum opcodes {
    /* 所有 R 类型指令的操作码都是 SPECIAL 指令: 操作码 = 0  */
    OP_SPECIAL = 0b000000, 

    /* I 类型指令。最大范围: 1 - 63 */
    /* I 类型 ALU 指令。 */
    OP_ADDI = 0b001000, 
    OP_ADDUI = 0b001001, 
    OP_ANDI = 0b001100, 
    OP_ORI = 0b001101, 
    OP_XORI = 0b001110, 
    OP_LUI = 0b001111, 

    /* I 类型分支和跳转指令。 */
    OP_BEQ = 0b000100, 
    OP_BNE = 0b000101, 
    OP_SLTI = 0b001010, 
    OP_SLTIU = 0b001011, 

    /* I 类型加载和存储指令。 */
    OP_LW = 0b100011, 
    OP_SW = 0b101011, 

    /* J 类型指令。 */
    OP_J = 0b000010, 
    OP_JAL = 0b000011, 

    /* 浮点类型指令 */
    OP_FR = 0b010001,
    OP_LWC1 = 0b110001,
    OP_SWC1 = 0b111001,

        /* !!! 不要移除这个条目 !!!
       这个条目用于标记操作码数组的结束，以便我们可以检查是否定义了超过 64 个操作码！
    */ 
    NUM_OPCODES 
};

enum functions {
    OP_ADD = 0b100000, 
    OP_ADDU = 0b100001, 
    OP_SUB = 0b100010, 
    OP_SUBU = 0b100011, 
    OP_AND = 0b100100, 
    OP_OR = 0b100101, 
    OP_XOR = 0b100110, 
    OP_NOR = 0b100111, 
    OP_SLT = 0b101010, 
    OP_SLTU = 0b101011, 
    OP_SLL = 0b000000, 
    OP_SRL = 0b000010, 
    OP_SRA = 0b000011, 
    OP_SLLV = 0b000100, 
    OP_SRLV = 0b000110, 
    OP_SRAV = 0b000111, 
    OP_JR =   0b001000, 
    /* !!! 不要移除这个条目 !!!
       这个条目用于标记功能数组的结束，以便我们可以检查是否定义了超过 2048 个功能字段！
    */ 
    NUM_FUNCS 
};

enum funt {
    OP_ADD_S = 0b000000,
    OP_MUL_S = 0b000010,
    NUM_FUNT
};

