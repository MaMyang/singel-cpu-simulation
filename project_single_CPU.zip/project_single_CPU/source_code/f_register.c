#include <stdio.h>
#include <stdlib.h>

int freg_size = 32 ;
float *f;

float get_float (long addr)
{
    return *((float *) (f + addr));
}

void put_float (long addr , float val)
{
    *((float *)(f + addr)) = val ;
}

// 初始化寄存器文件
void init_f_registers() {
    // 分配32个float大小的内存空间给浮点寄存器文件
    f = (float *)malloc(sizeof(float) * freg_size);
    if (f == NULL) {
        printf("error: float register file allocation\n");
        exit(-1);
    }
    // 初始化浮点寄存器为0.0
    for (int i = 0; i < freg_size; i++) {
        put_float(i, 0.0f);
    }
}

void free_f_registers() {
     free(f);
}