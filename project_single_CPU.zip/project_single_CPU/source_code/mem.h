#ifndef MEM_H
#define MEM_H

#include <stdio.h>
#include <stdlib.h>

extern char *mem; // 声明主存起始地址指针为外部变量
extern int mem_size; // 声明主存大小为外部变量

// 函数声明
unsigned char read_mem_ubyte(long addr);
void write_mem_ubyte(long addr, unsigned char val);

char read_mem_byte(long addr);
void write_mem_byte(long addr, char val);

unsigned short read_mem_uhalf_word(long addr);
void write_mem_uhalf_word(long addr, unsigned short val);

short read_mem_half_word(long addr);
void write_mem_half_word(long addr, short val);

unsigned int read_mem_uword(long addr);
void write_mem_uword(long addr, unsigned int val);

int read_mem_word(long addr);
void write_mem_word(long addr, int val);

float read_mem_float(long addr);
void write_mem_float(long addr, float val);

double read_mem_double(long addr);
void write_mem_double(long addr, double val);

void init_mem();
void free_mem();

#endif // MEM_H
