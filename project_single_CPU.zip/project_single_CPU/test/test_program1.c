//test_float.c
#include <stdio.h>
#include <stdlib.h>
#include "mem.h"
#include "opcode_and_function.h"
#include "Registers.h"
#include "f_register.h"
#include "Instruction.h"

#define ARRAY_SIZE 64
#define LOOP_ADDR 0x2000  // 循环代码起始地址

int main() {
    // 初始化系统
    init_mem();
    init_registers();
    init_f_registers();

    // 初始化数据
    float d = 0.9f;
    float c = 0.5f;
    
    // 在内存中设置常数
    write_mem_float(0x1000, d);  // 存储d到0x1000
    write_mem_float(0x1004, c);  // 存储常数0.5到0x1004

        // 初始化浮点数组fa（地址0x2000-0x2100）
        for(int i=0; i<ARRAY_SIZE; i++){
            write_mem_float(0x2000 + i*4, (float)1);  // fa[i] = i
        }

    // 编写MIPS指令到指令内存（从0x3000开始）
    // 指令序列：
    // 1. 加载常数
    // 2. 循环处理数组
    write_mem_uword(0x3000, 0xC4101000); // LWC1 $f16, 0x1000($zero)  # 加载d
    write_mem_uword(0x3004, 0xC4111004); // LWC1 $f17, 0x1004($zero) # 加载0.5
    write_mem_uword(0x3008, 0x20080000); // ADDI $t0, $zero, 0        # i=0
    write_mem_uword(0x300C, 0x20090040); // ADDI $t1, $zero, 64       # 数组长度
    
    // 主循环
// LOOP 开始地址: 0x3010
    write_mem_uword(0x3010, 0x0109502A); // SLT  $t2, $t0, $t1   // 检查 i < 64
    write_mem_uword(0x3014, 0x11400008); // BEQ  $t2, $0, EXIT    // 若 i >= 64 则退出
    write_mem_uword(0x3018, 0x24012000); // ADDUI $at, $0, 0x2000 // 数组基地址
    write_mem_uword(0x301C, 0x00081080); // SLL  $v0, $t0, 2     // i*4（浮点步长）
    write_mem_uword(0x3020, 0x00220820); // ADD  $at, $at, $v0   // 计算元素地址
    write_mem_uword(0x3024, 0xC4200000); // LWC1 $f0, 0($at)     // 加载 fa[i]
    write_mem_uword(0x3028, 0x46100002); // MUL.S $f0, $f0, $f16 // fa[i] * d
    write_mem_uword(0x302C, 0x46110000); // ADD.S $f0, $f0, $f17 // 加 0.5
    write_mem_uword(0x3030, 0xE4200000); // SWC1 $f0, 0($at)     // 存回内存
    write_mem_uword(0x3034, 0x21080001); // ADDI $t0, $t0, 1     // i++（关键修改点）
    write_mem_uword(0x3038, 0x08000C04); // J     LOOP            // 跳转到 LOOP（地址 0x3010）
    write_mem_uword(0x303C, 0x00000008); // EXIT: JR   $ra        // 程序结束
    // 执行程序
    write_mem_uword(0x303C, 0x00000000); // NOP 占位符

    // 设置PC并执行
    Execution();

    // 验证结果
    printf("Verification:\n");
    for(int i=0; i<64; i++){  // 检查前5个元素
        float val = read_mem_float(0x2000 + i*4);
        printf("fa[%d] = %.2f\n", i, val);
    }

    // 清理资源
    free_mem();
    free_registers();
    free_f_registers();
    
    return 0;
}
