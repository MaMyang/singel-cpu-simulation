// Registers.h

#ifndef REGISTERS_H
#define REGISTERS_H

#include <stdio.h>
#include <stdlib.h>

// 声明通用寄存器文件的大小
extern int ireg_size;

// 声明通用寄存器文件的起始地址指针
extern int *r;

// 声明读取寄存器中整数值的函数
int get_int(long addr);

// 声明写入寄存器中整数值的函数
void put_int(long addr, int val);

// 声明读取寄存器中无符号整数值的函数
int get_uint(long addr);

// 声明写入寄存器中无符号整数值的函数
void put_uint(long addr, unsigned int val);

void init_registers();

void free_registers();

#endif // REGISTERS_H
