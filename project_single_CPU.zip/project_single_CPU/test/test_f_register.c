#include "f_register.h"

int main() {
    // 初始化寄存器文件
    init_f_registers();

    // 测试 put_float 和 get_float 函数
    float test_value_1 = 3.14f;
    float test_value_2 = 2.71f;
    float test_value_3 = 0.577f;

    // 写入一些值到寄存器中
    put_float(0, test_value_1);
    put_float(1, test_value_2);
    put_float(2, test_value_3);

    // 读取并打印寄存器中的值
    printf("f0: %f\n", get_float(0));
    printf("f1: %f\n", get_float(1));
    printf("f2: %f\n", get_float(2));

    // 释放寄存器文件
    free_f_registers();

    return 0;
}
