#ifndef F_REGISTER_H
#define F_REGISTER_H

#include <stdio.h>
#include <stdlib.h>

// 浮点寄存器文件的大小
extern int freg_size;

// 浮点寄存器文件起始地址指针
extern float *f;

// 获取浮点数寄存器的值
float get_float(long addr);

// 设置浮点数寄存器的值
void put_float(long addr, float val);

// 初始化寄存器文件
void init_f_registers();

// 释放寄存器文件
void free_f_registers();

#endif // F_REGISTER_H
