//Instruction.c
#include <stdio.h>
#include <stdlib.h>
#include "mem.h" // 包含内存模拟的头文件
#include "opcode_and_function.h"
#include "Registers.h"
#include "f_register.h"
#define R0 0 

// 全局变量声明
long pc;
int OPCODE;
int RS1;
int RS2;
int RD;
int IMM;
unsigned int UIMM;
int FUNC;
unsigned int SHAMT;
int OFFSET;
int FMT;
int FRS1;
int FRS2;
int FRD;
int FUNCT;

void MIPS_decoder(long pc) 
{
    unsigned int insn = read_mem_uword(pc);
    OPCODE   = (insn >> 26) & 0x3f; 
    RS1      = (insn >> 21) & 0x1f; 
    RS2      = (insn >> 16) & 0x1f; 
    RD       = (insn >> 11) & 0x1f;
    SHAMT    = (insn >> 6)  & 0x1f;  // 新增SHAMT字段
    FUNC     = insn & 0x3f; 
    IMM      = (int)((short)(insn & 0xffff));  //15-0 位（立即数）
    UIMM     = (unsigned int)(insn & 0xffff);
    OFFSET   = insn & 0x3ffffff;    
    FMT      = (insn >> 21) & 0x7;  // 浮点格式字段，位于指令的第 21-23 位
    FRS1     = (insn >> 16) & 0x1f;  // 浮点源寄存器 1，位于指令的第 16-20 位
    FRS2     = (insn >> 11) & 0x1f;  // 浮点源寄存器 2，位于指令的第 11-15 位
    FRD      = (insn >> 6)  & 0x1f;  // 浮点目的寄存器，位于指令的第 6-10 位
    FUNCT    = insn & 0x3f;  // 浮点函数码，位于指令的低 6 位

    // 打印指令的各个部分
  // printf("Opcode: %d, RS1: %d, RS2: %d, RD: %d, SHAMT: %d, IMM: %d, UIMM: %u, FUNC: %d, OFFSET: %d, FMT: %d, FRS1: %d, FRS2: %d, FRD: %d, FUNCT: %d\n", 
    //    OPCODE, RS1, RS2, RD, SHAMT, IMM, UIMM, FUNC, OFFSET, FMT, FRS1, FRS2, FRD, FUNCT); // 修改后包含浮点指令字段
}

// R型指令: ADD, ADDU, SUB, SUBU, AND, OR, XOR, NOR, SLT, SLTU, SLL, SRL, SRA, SLLV, SRLV, SRAV, JR
long INSN_ADD(long pc) 
{ 
    int *rd  = r + RD;   // R-型指令的目的寄存器为RD 
    int rs1  = get_int(RS1); // R-型指令的源操作数1为RS1，将其视作有符号数 
    int rs2  = get_int(RS2);  // R-型指令的源操作数2为RS2，将其视作有符号数 
    *rd = rs1 + rs2;   // 可以直接将计算结果写回目的寄存器 
    printf("Executing ADD: R%d = R%d + R%d => R%d = %d\n", RD, RS1, RS2, RD, *rd); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令
}

long INSN_ADDU(long pc) 
{ 
    unsigned int *rd  = r + RD;   // I-型指令的目的寄存器为RD 
    unsigned int rs1  = get_uint(RS1); // I-型指令的源操作数1为RS1（无符号数） 
    unsigned int rs2  = get_uint(RS2);  // I-型指令的源操作数2为RS2（无符号数） 
    *rd = rs1 + rs2;     // 可以直接将计算结果写回目的寄存器 
    printf("Executing ADDU: R%d = R%d + R%d => R%d = %u\n", RD, RS1, RS2, RD, *rd); // 输出当前指令执行的结果
    return pc + 4;      // pc的值加4，指向顺序的下一条指令 
} 

long INSN_SUB(long pc)
{
    int *rd  = r + RD;   // R-型指令的目的寄存器为RD
    int rs1  = get_int(RS1); // R-型指令的源操作数1为RS1，将其视作有符号数
    int rs2  = get_int(RS2);  // R-型指令的源操作数2为RS2，将其视作有符号数
    *rd = rs1 - rs2;   // 可以直接将计算结果写回目的寄存器
    printf("Executing SUB: R%d = R%d - R%d => R%d = %d\n", RD, RS1, RS2, RD, *rd); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令
}

long INSN_SUBU(long pc)
{
    unsigned int *rd  = r + RD;   // R-型指令的目的寄存器为RD
    unsigned int rs1  = get_uint(RS1); // R-型指令的源操作数1为RS1（无符号数）
    unsigned int rs2  = get_uint(RS2);  // R-型指令的源操作数2为RS2（无符号数）
    *rd = rs1 - rs2;  // 可以直接将计算结果写回目的寄存器
    printf("Executing SUBU: R%d = R%d - R%d => R%d = %u\n", RD, RS1, RS2, RD, *rd); // 输出当前指令执行的结果
    return pc + 4;  // pc的值加4，指向顺序的下一条指令
}

long INSN_AND(long pc)
{
    int *rd  = r + RD;   // R-型指令的目的寄存器为RD
    int rs1  = get_int(RS1); // R-型指令的源操作数1为RS1
    int rs2  = get_int(RS2);  // R-型指令的源操作数2为RS2
    *rd = rs1 & rs2;   // 可以直接将计算结果写回目的寄存器
    printf("Executing AND: R%d = R%d & R%d => R%d = %d\n", RD, RS1, RS2, RD, *rd); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令
}

long INSN_OR(long pc) 
{
    int *rd = r + RD;         // R-型指令的目的寄存器为RD
    int rs1 = get_int(RS1);   // 获取源操作数1（RS1）的值
    int rs2 = get_int(RS2);   // 获取源操作数2（RS2）的值
    *rd = rs1 | rs2;          // 执行按位“或”操作，将结果存储到目的寄存器
    printf("Executing OR: R%d = R%d | R%d => R%d = %d\n", RD, RS1, RS2, RD, *rd); // 输出当前指令执行的结果
    return pc + 4;           // 更新程序计数器，指向下一条指令
}

long INSN_XOR(long pc)
{
    int *rd = r + RD; // R-型指令的目的寄存器为RD
    int rs1 = get_int(RS1); // R-型指令的源操作数1为RS1
    int rs2 = get_int(RS2); // R-型指令的源操作数2为RS2
    *rd = rs1 ^ rs2; // 异或操作
    printf("Executing XOR: R%d = R%d ^ R%d => R%d = %d\n", RD, RS1, RS2, RD, *rd); // 输出当前指令执行的结果
    return pc + 4; // 更新程序计数器，指向下一条指令
}

long INSN_NOR(long pc)
{
    int *rd = r + RD; // R-型指令的目的寄存器为RD
    int rs1 = get_int(RS1); // R-型指令的源操作数1为RS1
    int rs2 = get_int(RS2); // R-型指令的源操作数2为RS2
    *rd = ~(rs1 | rs2); // 或非操作
    printf("Executing NOR: R%d = ~(R%d | R%d) => R%d = %d\n", RD, RS1, RS2, RD, *rd); // 输出当前指令执行的结果
    return pc + 4; // 更新程序计数器，指向下一条指令
}

long INSN_SLT(long pc)
{
    int *rd = r + RD; // R-型指令的目的寄存器为RD
    int rs1 = get_int(RS1); // R-型指令的源操作数1为RS1
    int rs2 = get_int(RS2); // R-型指令的源操作数2为RS2
    *rd = (rs1 < rs2) ? 1 : 0; // 有符号比较，若rs1 < rs2，则rd = 1，否则rd = 0
    printf("Executing SLT: R%d = (R%d < R%d) => R%d = %d\n", RD, RS1, RS2, RD, *rd); // 输出当前指令执行的结果
    return pc + 4; // 更新程序计数器，指向下一条指令
}

long INSN_SLTU(long pc)
{
    unsigned int *rd = r + RD; // R-型指令的目的寄存器为RD
    unsigned int rs1 = get_uint(RS1); // R-型指令的源操作数1为RS1（无符号数）
    unsigned int rs2 = get_uint(RS2); // R-型指令的源操作数2为RS2（无符号数）
    *rd = (rs1 < rs2) ? 1 : 0; // 无符号比较，若rs1 < rs2，则rd = 1，否则rd = 0
    printf("Executing SLTU: R%d = (R%d < R%d) => R%d = %u\n", RD, RS1, RS2, RD, *rd); // 输出当前指令执行的结果
    return pc + 4; // 更新程序计数器，指向下一条指令
}

// 实现SLL指令
long INSN_SLL(long pc) 
{ 
    int *rd  = r + RD;   // R-型指令的目的寄存器为RD 
    int rs1  = get_int(RS1); // R-型指令的源操作数1为RS1 
    int shamt  = SHAMT;  // 移位量为指令中的SHAMT字段 
    *rd = rs1 << shamt;   // 左移操作 
    printf("Executing SLL: R%d = R%d << %d => R%d = %d\n", RD, RS1, shamt, RD, *rd); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令
}

// 实现SRL指令
long INSN_SRL(long pc) 
{ 
    unsigned int *rd  = r + RD;   // R-型指令的目的寄存器为RD 
    unsigned int rs1  = get_uint(RS1); // R-型指令的源操作数1为RS1（无符号数） 
    int shamt  = SHAMT;  // 移位量为指令中的SHAMT字段 
    *rd = rs1 >> shamt;   // 逻辑右移操作 
    printf("Executing SRL: R%d = R%d >> %d => R%d = %u\n", RD, RS1, shamt, RD, *rd); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令
}

// 实现SRA指令
long INSN_SRA(long pc) 
{ 
    int *rd  = r + RD;   // R-型指令的目的寄存器为RD 
    int rs1  = get_int(RS1); // R-型指令的源操作数1为RS1 
    int shamt  = SHAMT;  // 移位量为指令中的SHAMT字段 
    *rd = rs1 >> shamt;   // 算术右移操作 
    printf("Executing SRA: R%d = R%d >> %d => R%d = %d\n", RD, RS1, shamt, RD, *rd); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令
}

long INSN_SLLV(long pc)
{
    int *rd  = r + RD;   // R-型指令的目的寄存器为RD 
    int rt   = get_int(RS2); // R-型指令的源操作数2为RS2，将其视作有符号数 
    int rs   = get_int(RS1) & 0x1f; // R-型指令的源操作数1为RS1，将其视作有符号数，并且只取低5位
    *rd = rt << rs;   // 可以直接将计算结果写回目的寄存器 
    printf("Executing SLLV: R%d = R%d << R%d => R%d = %d\n", RD, RS2, RS1, RD, *rd); // 输出当前指令执行的结果
    return pc + 4;   // pc的值加4，指向顺序的下一条指令
}

long INSN_SRLV(long pc)
{
    unsigned int *rd  = r + RD;   // R-型指令的目的寄存器为RD 
    unsigned int rt   = get_uint(RS2); // R-型指令的源操作数2为RS2，将其视作无符号数 
    unsigned int rs   = get_uint(RS1) & 0x1f; // R-型指令的源操作数1为RS1，将其视作无符号数，并且只取低5位
    *rd = rt >> rs;   // 可以直接将计算结果写回目的寄存器 
    printf("Executing SRLV: R%d = R%d >> R%d => R%d = %u\n", RD, RS2, RS1, RD, *rd); // 输出当前指令执行的结果
    return pc + 4;   // pc的值加4，指向顺序的下一条指令
}

long INSN_SRAV(long pc)
{
    int *rd  = r + RD;   // R-型指令的目的寄存器为RD 
    int rt   = get_int(RS2); // R-型指令的源操作数2为RS2，将其视作有符号数 
    int rs   = get_int(RS1) & 0x1f; // R-型指令的源操作数1为RS1，将其视作有符号数，并且只取低5位
    *rd = rt >> rs;   // 可以直接将计算结果写回目的寄存器 
    printf("Executing SRAV: R%d = R%d >> R%d => R%d = %d\n", RD, RS2, RS1, RD, *rd); // 输出当前指令执行的结果
    return pc + 4;   // pc的值加4，指向顺序的下一条指令
}

long INSN_JR(long pc) 
{ 
    return get_int(RS1); 
} 

// 实现I型指令

long INSN_ADDI(long pc) 
{ 
    int *rd  = r + RS2;  // I-型指令的目的寄存器为RS2 
    int rs   = get_int(RS1); // I-型指令的源操作数1为RS1，将其视作有符号数 
    *rd = rs + IMM;   // I-型指令的源操作数2为有符号数IMM  
    printf("Executing ADDI: R%d = R%d + %d => R%d = %d\n", RS2, RS1, IMM, RS2, *rd); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令 
}

long INSN_ADDUI(long pc) 
{ 
    unsigned int *rd  = r + RS2;   // I-型指令的目的寄存器为RS2 
    unsigned int rs   = get_int(RS1); // I-型指令的源操作数1为RS1（无符号数） 
    *rd = rs + UIMM;     // I-型指令的源操作数2为无符号数UIMM  
    printf("Executing ADDUI: R%d = R%d + %x => R%d = %x\n", RS2, RS1, UIMM, RS2, *rd); // 输出当前指令执行的结果
    return pc + 4;      // pc的值加4，指向顺序的下一条指令 
} 

long INSN_ANDI(long pc)
{
    int *rt  = r + RS2;   // I-型指令的目的寄存器为RT
    int rs1  = get_int(RS1); // I-型指令的源操作数1为RS1，将其视作有符号数
    unsigned int imm  = UIMM; // I-型指令的立即数为IMM，将其视作零扩展数
    *rt = rs1 & imm;   // 可以直接将计算结果写回目的寄存器
    printf("Executing ANDI: R%d = R%d & %u => R%d = %d\n", RS2, RS1, imm, RS2, *rt); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令
}

long INSN_ORI(long pc)
{
    int *rt  = r + RS2;   // I-型指令的目的寄存器为RT
    int rs1  = get_int(RS1); // I-型指令的源操作数1为RS1，将其视作有符号数
    unsigned int imm  = UIMM; // I-型指令的立即数为IMM，将其视作零扩展数
    *rt = rs1 | imm;   // 可以直接将计算结果写回目的寄存器
    printf("Executing ORI: R%d = R%d | %u => R%d = %d\n", RS2, RS1, imm, RS2, *rt); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令
}

long INSN_XORI(long pc)
{
    int *rt  = r + RS2;   // I-型指令的目的寄存器为RT
    int rs1  = get_int(RS1); // I-型指令的源操作数1为RS1，将其视作有符号数
    unsigned int imm  = UIMM; // I-型指令的立即数为IMM，将其视作零扩展数
    *rt = rs1 ^ imm;   // 可以直接将计算结果写回目的寄存器
    printf("Executing XORI: R%d = R%d ^ %u => R%d = %d\n", RS2, RS1, imm, RS2, *rt); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令
}

long INSN_LUI(long pc)
{
    unsigned int *rt  = r + RS2;   // I-型指令的目的寄存器为RT
    unsigned int imm  = UIMM; // I-型指令的立即数为IMM，将其视作零扩展数
    *rt = imm << 16;   // 可以直接将计算结果写回目的寄存器
    printf("Executing LUI: R%d = %x << 16 => R%d = %x\n", RS2, imm, RS2, *rt); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令
}

long INSN_LW(long pc)
{
    int *rt  = r + RS2;   // I-型指令的目的寄存器为RT
    int rs1 = get_int(RS1); // I-型指令的源操作数1为RS1，将其视作有符号数
    int imm = IMM; // I-型指令的立即数为IMM，将其视作符号数
    int addr = rs1 + imm; // 计算内存地址
    *rt = mem[addr];   // 从内存中读取数据并写入目的寄存器
    printf("Executing LW: R%d = mem[%d] => R%d = %d\n", RS2, addr, RS2, *rt); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令
}

long INSN_SW(long pc)
{
    int rs1 = get_int(RS1); // I-型指令的源操作数1为RS1，将其视作有符号数
    int rt = get_int(RS2); // I-型指令的源操作数2为RT，将其视作有符号数
    int imm = IMM; // I-型指令的立即数为IMM，将其视作符号数
    int addr = rs1 + imm; // 计算内存地址
    mem[addr] = rt;   // 将源寄存器中的数据写入内存
    printf("Executing SW: mem[%d] = R%d => mem[%d] = %d\n", addr, RS2, addr, rt); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令
}

long INSN_BEQ(long pc)
{
    int rs1  = get_int(RS1); // I-型指令的源操作数1为RS1，将其视作有符号数
    int rs2  = get_int(RS2);  // I-型指令的源操作数2为RS2，将其视作有符号数
    int offset = IMM; // I-型指令的立即数为IMM，将其视作符号数
    if (rs1 == rs2) // 如果rs1等于rs2
    {
        printf("Executing BEQ: Jumping to address 0x%lX\n", (pc + (offset << 2) + 4)); // 输出当前指令执行的结果
        return pc + (offset << 2) + 4; // 跳转到pc + offset*4，并且加上4是考虑到当前指令已经占用4个字节
    }
    else
    {
        printf("Executing BEQ: Not jumping, continuing to address %ld\n", pc + 4); // 输出当前指令执行的结果
        return pc + 4; // 否则顺序执行下一条指令
    }
}

long INSN_BNE(long pc)
{
    int rs1  = get_int(RS1); // I-型指令的源操作数1为RS1，将其视作有符号数
    int rs2  = get_int(RS2);  // I-型指令的源操作数2为RS2，将其视作有符号数
    int offset = IMM; // I-型指令的立即数为IMM，将其视作符号数
    if (rs1 != rs2) // 如果rs1不等于rs2
    {
        printf("Executing BNE: Jumping to address %ld\n", pc + (offset << 2) + 4); // 输出当前指令执行的结果
        return pc + (offset << 2) + 4; // 跳转到pc + offset*4，并且加上4是考虑到当前指令已经占用4个字节
    }
    else
    {
        printf("Executing BNE: Not jumping, continuing to address %ld\n", pc + 4); // 输出当前指令执行的结果
        return pc + 4; // 否则顺序执行下一条指令
    }
}

long INSN_SLTI(long pc)
{
    int *rt  = r + RS2;   // I-型指令的目的寄存器为RT
    int rs1 = get_int(RS1); // I-型指令的源操作数1为RS1，将其视作有符号数
    int imm = IMM; // I-型指令的立即数为IMM，将其视作符号数
    *rt = (rs1 < imm) ? 1 : 0;   // 可以直接将比较结果写回目的寄存器
    printf("Executing SLTI: R%d = (R%d < %d) => R%d = %d\n", RS2, RS1, imm, RS2, *rt); // 输出当前指令执行的结果
    return pc + 4;    // pc的值加4，指向顺序的下一条指令
}

long INSN_SLTIU(long pc)
{
    unsigned int *rt  = r + RS2;   // I-型指令的目的寄存器为RT
    unsigned int rs1  = get_uint(RS1); // I-型指令的源操作数1为RS1（无符号数）
    unsigned int imm  = UIMM; // I-型指令的立即数为IMM（无符号数）
    *rt = (rs1 < imm) ? 1 : 0;   // 可以直接将比较结果写回目的寄存器
    printf("Executing SLTIU: R%d = (R%d < %u) => R%d = %u\n", RS2, RS1, imm, RS2, *rt); // 输出当前指令执行的结果
    return pc + 4;      // pc的值加4，指向顺序的下一条指令
}

// J型指令

long INSN_J(long pc)
{
    pc = (pc & 0xf0000000) | ((OFFSET << 2) & 0x0fffffff); // 更新pc
    printf("Executing J: Jumping to address %ld\n", pc); // 输出当前指令执行的结果
    return pc;
}

long INSN_JAL(long pc)
{
    r[31] = pc + 4; // 将返回地址存入寄存器$31
    pc = (pc & 0xf0000000) | ((OFFSET << 2) & 0x0fffffff); // 更新pc
    printf("Executing JAL: Jumping to address %ld\n", pc); // 输出当前指令执行的结果
    return pc;
}

long INSN_NOP(long pc) 
{ 
    printf("Executing NOP: No operation\n"); // 输出当前指令执行的结果
    return pc + 4;
}

// 浮点型指令
long INSN_ADD_S(long pc)
{
    float rs1 = get_float(FRS1);
    float rs2 = get_float(FRS2);
    put_float(FRD, rs1 + rs2);
    printf("Executing ADD_S: F%d = F%d + F%d => F%d = %f\n", FRD, FRS1, FRS2, FRD, get_float(FRD)); // 输出当前指令执行的结果
    return pc + 4;
}

long INSN_MUL_S(long pc)
{
    float rs1 = get_float(FRS1); // 从浮点寄存器文件中获取第一个源操作数
    float rs2 = get_float(FRS2); // 从浮点寄存器文件中获取第二个源操作数
    put_float(FRD, rs1 * rs2); // 将计算结果写入浮点目的寄存器
    printf("Executing MUL_S: F%d = F%d * F%d => F%d = %f\n", FRD, FRS1, FRS2, FRD, get_float(FRD)); // 输出当前指令执行的结果
    return pc + 4; // 更新程序计数器，指向下一条指令
}

long INSN_LWC1(long pc) {
    int BASE = get_int(FMT);
    long addr = BASE + IMM;

    // 检查地址是否 4 字节对齐
    if (addr % 4 != 0) {
        fprintf(stderr, "[EXCEPTION] LWC1 un same size : 0x%lx (PC=0x%lx)\n", addr, pc);
        exit(1);
    }

    // 检查地址是否在 512KB 内存范围内
    if (addr < 0 || addr >= mem_size) {  // 地址范围 0x00000000~0x0007FFFF
        fprintf(stderr, "[EXCEPTION] LWC1 out size of mem: 0x%lx (PC=0x%lx)\n", addr, pc);
        exit(1);
    }
    // 读取内存并写入浮点寄存器
    float value = read_mem_float(addr);
    put_float(FRS1, value);
    printf("Executing LWC1: F%d = mem[%ld] => F%d = %f\n", FRS1, addr, FRS1, value);
    return pc + 4;
}


long INSN_SWC1(long pc)
{
    int BASE = get_int(FMT);
    int imm = (int)(short)IMM;
    long addr = BASE + imm;
    float value = get_float(FRS1);
    write_mem_float(addr, value);
    printf("Executing SWC1: mem[%ld] = F%d => mem[%ld] = %f\n", addr, FRS1, addr, value); // 输出当前指令执行的结果
    return pc + 4;
}



void Execution(void) 
{ 
pc = 0x3000;         // 将程序的入口地址设为0x3000 
for ( ; pc; ) 
{ 
unsigned int insn = read_mem_uword( pc );  // 读第一条指令 
MIPS_decoder(pc);

// 指令译码 
if ( OPCODE )        // 若不是R型指令 
{ 
    if (OPCODE == OP_FR)
    {
        switch (FUNCT)
        {
            case OP_ADD_S: pc=INSN_ADD_S(pc); break;
            case OP_MUL_S: pc=INSN_MUL_S(pc); break;
        default:
            printf( "FLOAT R table error: unimplemented instruction\n" ); exit( -1 ); 
        }
    }
    else
    {
        switch ( OPCODE ) 
        { 
            case OP_ADDI: pc = INSN_ADDI( pc ); break; 
            case OP_ADDUI: pc = INSN_ADDUI( pc ); break; 
            case OP_ANDI: pc = INSN_ANDI( pc ); break; 
            case OP_ORI: pc = INSN_ORI( pc ); break; 
            case OP_XORI: pc = INSN_XORI( pc ); break; 
            case OP_LUI: pc = INSN_LUI( pc ); break; 
            case OP_LW: pc = INSN_LW( pc ); break; 
            case OP_SW: pc = INSN_SW( pc ); break; 
            case OP_BEQ: pc = INSN_BEQ( pc ); break; 
            case OP_BNE: pc = INSN_BNE( pc ); break; 
            case OP_SLTI: pc = INSN_SLTI( pc ); break; 
            case OP_SLTIU: pc = INSN_SLTIU( pc ); break; 
            case OP_J: pc = INSN_J( pc ); break; 
            case OP_JAL: pc = INSN_JAL( pc ); break; 
            case OP_SWC1: pc = INSN_SWC1(pc);break;
            case OP_LWC1: pc = INSN_LWC1(pc);break;
            // 增加其他I型、J型指令,浮点型的实现 
            default: printf( "I/J error: unimplemented instruction\n" ); exit( -1 ); 
        } // end switch( OPCODE )
    }
} // end if ( OPCODE ) 
else 
{ 
    switch ( FUNC ) 
    { 
        case OP_ADD: pc = INSN_ADD( pc ); break; 
        case OP_ADDU: pc = INSN_ADDU( pc ); break; 
        case OP_SUB: pc = INSN_SUB( pc ); break;
        case OP_SUBU: pc = INSN_SUBU( pc ); break;
        case OP_AND: pc = INSN_AND( pc ); break;
        case OP_OR: pc = INSN_OR( pc ); break;
        case OP_XOR: pc = INSN_XOR( pc ); break;
        case OP_NOR: pc = INSN_NOR( pc ); break;
        case OP_SLT: pc = INSN_SLT( pc ); break;
        case OP_SLTU: pc = INSN_SLTU( pc ); break;
        case OP_SLL: pc = INSN_SLL( pc ); break;
        case OP_SRL: pc = INSN_SRL( pc ); break;
        case OP_SRA: pc = INSN_SRA( pc ); break;
        case OP_SLLV: pc = INSN_SLLV( pc ); break;
        case OP_SRLV: pc = INSN_SRLV( pc ); break;
        case OP_SRAV: pc = INSN_SRAV( pc ); break;
        case OP_JR: pc = INSN_JR(pc); break;

        // 增加其他R型指令的实现 
        default: printf( "R error: unimplemented instruction\n" ); exit( -1 ); 
    } // end switch(FUNC) 
} // end else 
} // end for 
} // end Execution() 

